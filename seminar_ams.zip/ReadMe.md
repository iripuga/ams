# ams
Odpravljanje suma v MR slikah z avtoenkoderji

1. V Google Drive je potrebno v direktorij /Colab\ Notebooks naložiti skripto main.ipynb

2. V direktorij /Colab\ Notebooks naložimo mapo /data, ki vsebuje mapi /multisite-benchmark in /normal-subjects

3. V direktorij /Colab\ Notebooks/data naložimo še naučene modele avtoenkoderjev z imeni AE1a, AE1b, AE1c, AE2a, AE2b, AE2c in knjižnico amslib.py

4. Poženemo skripto main.ipynb v kateri so nadaljna navodila